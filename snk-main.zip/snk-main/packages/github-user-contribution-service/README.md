# @snk/github-user-contribution-service

Expose github-user-contribution as an endpoint, using vercel.sh
